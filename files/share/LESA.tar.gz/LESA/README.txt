Call function computeLESA.m to obtain a Largest Empty Sector Angle representation of the points in the image

example.m presents a demo of how to use LESA values to obtain a hull for the set of points
