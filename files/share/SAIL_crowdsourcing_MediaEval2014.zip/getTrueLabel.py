#################################
#	Author : Naveen Kumar
#	Aff :	SAIL, USC
#	Email : komathnk@usc.edu
# 	Date : 21st Sept., 2014
#	File : getTrueLabel.py
################################# 


import sys
from collections import defaultdict
import numpy as np
from scipy import stats

#Use labels
#1,2,3,4

count_annotations=defaultdict(int)
clip_id=[]

stored_annots_by_id=[]

K=4	#number of classes
M=8 	#number of annotators (M-1 top annotators retained, last annotator is all others grouped)

#Read in all noisy annotations 
for line in sys.stdin:
	line=line.rstrip().split()

	clip_id.append(line[0])

	ann_for_this_clip={}

	for annot in line[1:]:
		annot=annot.split(':')
		annid=annot[1]
		label=int(annot[0])
		
		ann_for_this_clip[annid]=label
		count_annotations[annid]+=1

	stored_annots_by_id.append(ann_for_this_clip)

N=len(stored_annots_by_id)


#Assign ids to annotators  based on annotations count and retain top M-1 ones
annids=sorted(count_annotations.keys(),key= lambda a : count_annotations[a],reverse=True)[:M-1]

annots_per_clip=np.zeros((N,M))

for i,annot in enumerate(stored_annots_by_id):
	for id in annot:
		if id not in annids:	#Belongs to residual annotator id
			m=M-1	#Assign all other annotators to the last id 
		else:
			m=annids.index(id)

		annots_per_clip[i,m]=annot[id]



#Data set is now ready N clips and M annotators : 0 indicates no annotation

#EM parameters
LL=0
maxiter=300
th=0.0001
eps=1e-12	#Smoothing

#Class posterior

#Initialize with simple plurality instead
gamma=np.zeros((N,K))
for i,a in enumerate(stored_annots_by_id):
	majority_label=int(stats.mstats.mode(np.array(a.values()))[0][0])
	gamma[i,majority_label-1]=1

#Initialize gamma randomly
#gamma=np.random.rand(N,K)
#gamma=(gamma.T/np.sum(gamma,axis=1)).T

#model parameters
Eta=np.zeros(K)
Lambda=np.zeros((M,K,K))

for iter in xrange(maxiter):
	
	#print "Iteration :",iter

	#M-step
	Eta=np.sum(gamma,axis=0)/N 


	#Estimate noisy channel model for each annotator 
	for m in xrange(M):
		for a in xrange(K):
			for b in xrange(K):

				this_annotator=annots_per_clip[:,m]
				numerator=np.sum(gamma[this_annotator==a+1,b],axis=0); #(a,b,m)
				denominator=np.sum(gamma[this_annotator>0,b],axis=0) #(*,b,m)

				Lambda[m,a,b]=(numerator+eps)/(denominator+K*eps)



	#E-step
	for i in xrange(N):
		prob=np.ones(K)
		for k in range(K):
			for m in xrange(M):
				if annots_per_clip[i,m]>0:
					prob[k]*= Lambda[m,annots_per_clip[i,m]-1,k]
			prob[k]*=Eta[k]
		prob/=np.sum(prob)
		gamma[i,:]=prob


	#Compute LL

	PLL=LL
	LL=0
	for i in xrange(N):
		prob=np.ones(K)
		for k in range(K):
			for m in xrange(M):
				if annots_per_clip[i,m]>0:
					prob[k]*= Lambda[m,annots_per_clip[i,m]-1,k]
			prob[k]*=Eta[k]
		LL+=np.dot(np.log(prob),gamma[i,:])

	print>> sys.stderr, "LL :",LL/N

	if np.abs(PLL-LL)<N*th:
		break


#Store the soft class posteriors to a file
np.savetxt(sys.argv[1],gamma)


labels=np.argmax(gamma,axis=1)+1

#Print the class priors
print>>sys.stderr, Eta

#Print the thresholded class labels
for i in xrange(N):
	#print '%s,%d' %(','.join(clip_id[i].split('_')),labels[i])
	print '%s,%d' %(clip_id[i],labels[i])
