Expected format for the input file

>> file_id  label1:annotator1 label1:annotator1 label2:annotator1 ... 

The file should preferably be tab delimited with the labels, annotator id pair colon delimited. If you know annotator ids and they are variables for each sample you can use A1,A2 accordingly. Labels should be 1..K.

The program can be run as follows

>> python getTrueLabel.py softLabelFile.out < noisyAnnPerClip.txt > hardLabels.out

softLabels : num_samples X num_classes

The program outputs both the hard and soft labels

Program parameters of interest

K : Number of classes 
M : Number of annotators to use for modeling.(This can be less than the actual number of annotators).

When you run the program you should see average log likelihood (LL) steadily increasing. 
This indicates it's working fine  on your dataset.
